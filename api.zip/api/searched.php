<?php

// recieve search parameter
$bk = trim($_POST['bookname']);
$cURLConnection = curl_init();
curl_setopt($cURLConnection, CURLOPT_URL, 'https://www.anapioficeandfire.com/api/books/');
curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);


$apiList = curl_exec($cURLConnection);
$info = curl_getinfo($cURLConnection);
curl_close($cURLConnection);

$Response =json_decode($apiList, true);


$keys = array_keys($Response);

for($i = 0; $i < count($Response); $i++) {

    if($Response[$keys[$i]]['name']==$bk){
	
		
		echo "<pre>";
		echo json_encode( $Response[$keys[$i]], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
		echo "</pre>";
		}

    

    

}
?>