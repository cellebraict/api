<html>
<head>



</head>
<body>
<h2>Search for a book</h2>
<form method="post" action="searched.php">
<input type="text" name="bookname">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<input type="submit" value="submit" />

</form>

</body>
</html>